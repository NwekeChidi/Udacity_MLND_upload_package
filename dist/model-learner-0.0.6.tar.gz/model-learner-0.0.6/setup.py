# TODO: Fill out this file with information about your package

# HINT: Go back to the object-oriented programming lesson "Putting Code on PyPi" and "Exercise: Upload to PyPi"

# HINT: Here is an example of a setup.py file
# https://packaging.python.org/tutorials/packaging-projects/
from setuptools import setup

setup(name='model-learner',
      version='0.0.6',
      description='Data Analyzing and Model Engineering',
      packages=['model_learner'],
      author = 'Chidimma Dominic Nweke',
      author_email = 'realchidinweke@gmail.com',
      zip_safe=False)